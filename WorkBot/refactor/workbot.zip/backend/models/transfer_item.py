class TransferItem:

    def __init__(self, name: str, quantity: float):
        
        self.name = name
        self.quantity = quantity